from scheduler.trainer import Trainer
from scheduler.predictor import Predictor



def get_trainer(logger, writer):

    return Trainer(logger, writer)


def get_predictor(logger, writer):

    return Predictor(logger, writer)