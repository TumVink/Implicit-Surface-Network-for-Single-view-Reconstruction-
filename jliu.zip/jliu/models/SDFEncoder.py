import torch
import torch.nn as nn
import torch.nn.functional as F


class SDFEncoder(nn.Module):
    def __init__(self):
        super(SDFEncoder, self).__init__()
        self.block1 = nn.Sequential(
            nn.Conv2d(1,64,kernel_size=(3,3),stride=(2,2)),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.block2 = nn.Sequential(
            nn.Conv2d(64,512,kernel_size=(3,3),stride=(2,2)),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True)
        )
        self.block3 = nn.Sequential(
            nn.Conv2d(512,1024,kernel_size=(3,3),stride=(2,2)),
            nn.BatchNorm2d(1024),
            nn.ReLU(inplace=True)
        )
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                #nn.init.xavier_normal_(m.weight)
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, img):
        # x B*224*224 (only one view for one obj)
        
#         img_feat_temp=[]
#         for i in range(3):
#             x = self.block1(img[:,i,:,:])
#             img_featuremaps = self.block2(x) #5*56*56
#             img_feat_temp.append(img_featuremaps) #3*(5*56*56)
#         img_feat_2d = tensor.cat(img_feat_temp) 
        
        
        #print(img.size())
        x = self.block1(img)
        x = self.block2(x)
        out = self.block3(x)
        return out