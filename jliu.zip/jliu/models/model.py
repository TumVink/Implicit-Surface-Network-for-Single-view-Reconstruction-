import torch
import torch.nn as nn
import torch.nn.functional as F

#from models.backbones import get_backbone
from models.SDFEncoder import SDFEncoder
from models.SDFDecoder import SDFDecoder
from models.projection import PerceptualPooling


class Model(nn.Module):
    def __init__(self,options):
        super(Model, self).__init__()
        self.options = options
        self.nn_encoder = SDFEncoder()
        self.percep_pooling = PerceptualPooling()

        self.nn_decoder = SDFDecoder()

    def forward(self, input_batch):
        img = input_batch["images"] #B*3*224*224
        pc = input_batch["sdf_points"]
        pc_rot = input_batch["sdf_points_rot"]
        trans_mat = input_batch["trans_mat"] #B*3*4*3

        #batch_size = img.size(0)
        img_feat_local = []
        for i in range(3):
            img_4d = torch.unsqueeze(img[:,i,:,:],1) # from B*244*244 to B*1*244*244
            img_feat_2d = self.nn_encoder(img_4d)
            img_feat_local.append(self.percep_pooling(img_feat_2d,pc,trans_mat[:,i,:,:])) #B*512*1*4096  5:channel of feature maps
        img_feat_all = torch.cat((img_feat_local), dim=1) #B*(3*512)*1*4096
        #print(img_feat_all.size())
        pred_sdf = self.nn_decoder(img_feat_all)
        #print(pred_sdf.size())                       
        return {
            "pred_sdf": pred_sdf
        }