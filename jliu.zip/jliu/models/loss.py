import torch
import torch.nn as nn
import torch.nn.functional as F
import utils.config as config 


class SDFLoss(nn.Module):
    def __init__(self):
        super().__init__()
        self.sdf_coefficient = config.options.loss.sdf.coefficient #1000
        self.sdf_threshold = config.options.loss.sdf.threshold #0.01
        self.sdf_near_surface_weight = config.options.loss.sdf.weights.near_surface #4
        self.sdf_scale = config.options.loss.sdf.weights.scale #10

    def forward(self, pred_dict, input_batch):
        targets = input_batch["sdf_value"]
        #print(targets.size())
        outputs = torch.squeeze(pred_dict["pred_sdf"],1)#input_batch["sdf_value"]-0.01#pred_dict["pred_sdf"]
        #print(outputs.size())

        weight_mask = (targets < self.sdf_threshold).float() * self.sdf_near_surface_weight \
            + (targets >= self.sdf_threshold).float()  #4 for near surface,1 for others
        sdf_loss = torch.mean(torch.abs(targets * self.sdf_scale - outputs) *weight_mask)#* self.sdf_near_surface_weight) #no mask at all
        sdf_loss = sdf_loss * self.sdf_coefficient
        sdf_loss_realvalue = torch.mean(torch.abs(targets - outputs / self.sdf_scale))

        gt_sign = torch.gt(targets, 0.5)
        pred_sign = torch.gt(outputs, 0.5)
        accuracy = torch.mean(torch.eq(gt_sign, pred_sign).float())

        loss = sdf_loss

        return loss, {
            "loss": loss,
            "sdf_loss": sdf_loss,
            "sdf_loss_realvalue": sdf_loss_realvalue,
            "accuracy": accuracy,
        }