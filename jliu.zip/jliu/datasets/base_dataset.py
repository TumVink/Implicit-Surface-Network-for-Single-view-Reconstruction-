import json
import os
import pickle
from torch.utils.data.dataset import Dataset
import numpy as np
import torch
import h5py
import random
from PIL import Image
from skimage import transform,io
from torchvision.transforms import Normalize
# from torch.utils.data.dataloader import default_collate

import utils.config as config



class ShapeNet(Dataset):
    def __init__(self, file_root, file_list_name, img_dir, sdf_dir, normalization, shapenet_options=None, logger=None,mode='easy',phase='eva'):
        super(ShapeNet, self).__init__()
        self.file_root = file_root
        self.sdf_dir = os.path.join(self.file_root, sdf_dir)
        self.img_dir = os.path.join(self.file_root, img_dir)
        self.img_mode = mode
        self.normalize_img = Normalize(mean=config.IMG_NORM_MEAN, std=config.IMG_NORM_STD) # transform the img using torchvision
        
        #print(self.sdf_dir)
        #print(self.img_dir)
        self.file_names = []
        category_name = file_list_name.split("_")[0]
        with open(os.path.join(self.file_root, "meta", file_list_name), "r") as fp:
            for l in fp:
                #for r in range(config.NUM_IMG):
                self.file_names.append((category_name, l.strip()))
        self.normalization = normalization
        self.shapenet_options = shapenet_options
        self.logger = logger
        split = int(len(self.file_names)*0.7)
        #print(len(self.file_names))
        if phase=='train':
            self.file_names = self.file_names[0:split]
        elif phase=='eva':
            self.file_names = self.file_names[split:len(self.file_names)]
        print(self.file_names)
            

    def get_sdf_h5(self, sdf_h5_file, cat_id, obj):
        h5_f = h5py.File(sdf_h5_file, 'r')
        try:
            if ('pc_sdf_original' in h5_f.keys()
                    and 'pc_sdf_sample' in h5_f.keys()
                    and 'norm_params' in h5_f.keys()):
                ori_sdf = h5_f['pc_sdf_original'][:].astype(np.float32)
                #
                sample_sdf = h5_f['pc_sdf_sample'][:-10000].astype(np.float32)
                ori_pt = ori_sdf[:, :3]  # , ori_sdf[:,3]
                ori_sdf_val = None
                
                #save ori_sdf into file
                np.save('tmp/ort_sdf.npy',ori_sdf)
                tmp=h5_f['pc_sdf_sample'][:].astype(np.float32)
                np.save('tmp/sample_sdf.npy',tmp)
                #print("got")
                
                if sample_sdf.shape[1] == 4:
                    sample_pt, sample_sdf_val = sample_sdf[:, :3], sample_sdf[:, 3:]
                else:
                    sample_pt, sample_sdf_val = None, sample_sdf[:, 0]
                norm_params = h5_f['norm_params'][:]
                sdf_params = h5_f['sdf_params'][:]
            else:
                raise Exception(cat_id, obj, "no sdf and sample")
        finally:
            h5_f.close()
        return sample_pt, sample_sdf_val, norm_params, sdf_params
    
    def get_norm_matrix(self,sdf_h5_file):   
        
        with h5py.File(sdf_h5_file, 'r') as h5_f:
            norm_params = h5_f['norm_params'][:]
            center, m, = norm_params[:3], norm_params[3]
            x,y,z = center[0], center[1], center[2]
            M_inv = np.asarray(
                [[m, 0., 0., 0.],
                 [0., m, 0., 0.],
                 [0., 0., m, 0.],
                 [0., 0., 0., 1.]]
            )
            T_inv = np.asarray(
                [[1.0 , 0., 0., x],
                 [0., 1.0 , 0., y],
                 [0., 0., 1.0 , z],
                 [0., 0., 0., 1.]]
            )
        return np.matmul(T_inv, M_inv)   
    
    def get_rotate_matrix(self,rotation_angle1):
        
        cosval = np.cos(rotation_angle1)
        sinval = np.sin(rotation_angle1)

        rotation_matrix_x = np.array([[1, 0,        0,      0],
                                      [0, cosval, -sinval, 0],
                                      [0, sinval, cosval, 0],
                                      [0, 0,        0,      1]])
        rotation_matrix_y = np.array([[cosval, 0, sinval, 0],
                                      [0,       1,  0,      0],
                                      [-sinval, 0, cosval, 0],
                                      [0,       0,  0,      1]])
        rotation_matrix_z = np.array([[cosval, -sinval, 0, 0],
                                      [sinval, cosval, 0, 0],
                                      [0,           0,  1, 0],
                                      [0,           0,  0, 1]])
        scale_y_neg = np.array([
            [1, 0,  0, 0],
            [0, -1, 0, 0],
            [0, 0,  1, 0],
            [0, 0,  0, 1]
        ])

        neg = np.array([
            [-1, 0,  0, 0],
            [0, -1, 0, 0],
            [0, 0,  -1, 0],
            [0, 0,  0, 1]
        ])
        # y,z swap = x rotate -90, scale y -1
        # new_pts0[:, 1] = new_pts[:, 2]
        # new_pts0[:, 2] = new_pts[:, 1]
        #
        # x y swap + negative = z rotate -90, scale y -1
        # new_pts0[:, 0] = - new_pts0[:, 1] = - new_pts[:, 2]
        # new_pts0[:, 1] = - new_pts[:, 0]

        # return np.linalg.multi_dot([rotation_matrix_z, rotation_matrix_y, rotation_matrix_y, scale_y_neg, rotation_matrix_z, scale_y_neg, rotation_matrix_x])
        return np.linalg.multi_dot([neg, rotation_matrix_z, rotation_matrix_z, scale_y_neg, rotation_matrix_x])     
       
   
    def __getitem__(self, index):
        cat_id, obj = self.file_names[index]
        # read sdf
        sdf_file = os.path.join(self.sdf_dir, cat_id, obj, "ori_sample.h5")
        sample_pt, sample_sdf_val, norm_params, sdf_params = self.get_sdf_h5(sdf_file, cat_id, obj)
        sample_sdf_val = sample_sdf_val - 0.003  # the value of iso-surface 0.003
        sample_sdf_val = sample_sdf_val.T
        choice = np.asarray(random.sample(range(sample_pt.shape[0]), self.shapenet_options.num_points), dtype=np.int32)
        # read image
        img_dir = os.path.join(self.img_dir, cat_id, obj,self.img_mode)
        img, trans_mat = self.get_img_old(img_dir,sdf_file)
        # to tensor
        #img = torch.from_numpy(np.transpose(img, (2, 0, 1))) #order: channel, height, width
        img = torch.from_numpy(img)
        img_normalized = self.normalize_img(img) if self.normalization else img
        sdf_points = torch.from_numpy(sample_pt[choice, :])
        sdf_value = torch.from_numpy(sample_sdf_val[:, choice])
        norm_params = torch.from_numpy(norm_params)
        sdf_params = torch.from_numpy(sdf_params)
        trans_mat = torch.from_numpy(trans_mat)
        filenames = []
        num = np.array([0,16,31])
        for i in range(config.NUM_IMG):
            filename = '_'.join(map(lambda x: str(x), [cat_id, obj, num[i]]))
            filenames.append(filename)

        if self.shapenet_options.rot:
            sample_pt_rot = np.dot(sample_pt[choice, :], obj_rot_mat)
        else:
            sample_pt_rot = sample_pt[choice, :]
        sdf_points_rot = torch.from_numpy(sample_pt_rot)

        return {
            "images": img_normalized,
            "images_orig": img,
            "sdf_points": sdf_points,
            "sdf_points_rot": sdf_points_rot,
            "sdf_value": sdf_value,
            "norm_params": norm_params,
            "sdf_params": sdf_params,
            "trans_mat": trans_mat,
            "filename": filenames
        }

    def __len__(self):
        return len(self.file_names)
    
    def get_img_old(self, img_dir,sdf_fl):
        if config.NUM_IMG == 3:
            num = np.array([0,16,31])
        #load camera_matrix
        text_dir = img_dir + "/rendering_metadata.txt"
        with open(text_dir) as f_input:
            text = [l.replace(",", " ") for l in f_input]
            text = [l.replace("]", " ") for l in text]
            text = [l.replace("[", " ") for l in text]
        params = np.loadtxt(text)
        
        #load NUM of image to array [NUM, 244, 244]
        img_file = []
        img_arr = []
        trans_ls = []
        for i in range(config.NUM_IMG):
            # image files
            img_file.append(os.path.join(img_dir, "%02d.png"%num[i]))
            img = io.imread(img_file[i]).astype(np.float32)
            img = img[:,:,0]/255
            img_arr.append(img)
            # parameters
            param = params[num[i], :].astype(np.float32)
            # azimuth, elevation, in-plane rotation, distance, the field of view.
            # Calculate the translation matrix from 3d to 2d
            norm_mat = self.get_norm_matrix(sdf_fl)
            rot_mat = self.get_rotate_matrix(-np.pi / 2)
            az, el, distance_ratio = param[0], param[1], param[3]
            K, RT = self.getBlenderProj(az, el, distance_ratio, img_w=137, img_h=137)
            trans_mat = np.linalg.multi_dot([K, RT, rot_mat, norm_mat])
            trans_mat_right = np.transpose(trans_mat).astype(np.float32)
            #cam_mat.append(mat)
            trans_ls.append(trans_mat_right)
            #print("finish load: %02d"%num[i])
        img_arr = np.array(img_arr)
        trans_ls = np.array(trans_ls)
        
        return img_arr, trans_ls

       
    def camera_info(self, param):
        az_mat = self.get_az(param[0])
        el_mat = self.get_el(param[1])
        inl_mat = self.get_inl(param[2])
        cam_mat = np.transpose(np.matmul(np.matmul(inl_mat, el_mat), az_mat))
        cam_pos = self.get_cam_pos(param)
        return cam_mat, cam_pos  
    
    def degree2rad(self, params):
        params[0] = np.deg2rad(params[0] + 180.0)
        params[1] = np.deg2rad(params[1])
        params[2] = np.deg2rad(params[2])
        return params
    
    def get_az(self, az):
        cos = np.cos(az)
        sin = np.sin(az)
        mat = np.asarray([cos, 0.0, sin, 0.0, 1.0, 0.0, -1.0*sin, 0.0, cos], dtype=np.float32)
        mat = np.reshape(mat, [3,3])
        return mat
    
    def get_el(self, el):
        cos = np.cos(el)
        sin = np.sin(el)
        mat = np.asarray([1.0, 0.0, 0.0, 0.0, cos, -1.0*sin, 0.0, sin, cos], dtype=np.float32)
        mat = np.reshape(mat, [3,3])
        return mat
    
    def get_inl(self, inl):
        cos = np.cos(inl)
        sin = np.sin(inl)
        # zeros = np.zeros_like(inl)
        # ones = np.ones_like(inl)
        mat = np.asarray([cos, -1.0*sin, 0.0, sin, cos, 0.0, 0.0, 0.0, 1.0], dtype=np.float32)
        mat = np.reshape(mat, [3,3])
        return mat
    
    def get_cam_pos(self, param):
        camX = 0
        camY = 0
        camZ = param[3]
        cam_pos = np.array([camX, camY, camZ])
        return -1 * cam_pos
    
    def getBlenderProj(self,az, el, distance_ratio, img_w=137, img_h=137):
        """Calculate 4x3 3D to 2D projection matrix given viewpoint parameters."""
        F_MM = 35.  # Focal length
        SENSOR_SIZE_MM = 32.
        PIXEL_ASPECT_RATIO = 1.  # pixel_aspect_x / pixel_aspect_y
        RESOLUTION_PCT = 100.
        SKEW = 0.
        CAM_MAX_DIST = 1.75
        CAM_ROT = np.asarray([[1.910685676922942e-15, 4.371138828673793e-08, 1.0],
                          [1.0, -4.371138828673793e-08, -0.0],
                          [4.371138828673793e-08, 1.0, -4.371138828673793e-08]])

        # Calculate intrinsic matrix.
    # 2 atan(35 / 2*32)
        scale = RESOLUTION_PCT / 100
        # print('scale', scale)
        f_u = F_MM * img_w * scale / SENSOR_SIZE_MM
        f_v = F_MM * img_h * scale * PIXEL_ASPECT_RATIO / SENSOR_SIZE_MM
        # print('f_u', f_u, 'f_v', f_v)
        u_0 = img_w * scale / 2
        v_0 = img_h * scale / 2
        K = np.matrix(((f_u, SKEW, u_0), (0, f_v, v_0), (0, 0, 1)))

        # Calculate rotation and translation matrices.
        # Step 1: World coordinate to object coordinate.
        sa = np.sin(np.radians(-az))
        ca = np.cos(np.radians(-az))
        se = np.sin(np.radians(-el))
        ce = np.cos(np.radians(-el))
        R_world2obj = np.transpose(np.matrix(((ca * ce, -sa, ca * se),
                                              (sa * ce, ca, sa * se),
                                              (-se, 0, ce))))

        # Step 2: Object coordinate to camera coordinate.
        R_obj2cam = np.transpose(np.matrix(CAM_ROT))
        R_world2cam = R_obj2cam * R_world2obj
        cam_location = np.transpose(np.matrix((distance_ratio * CAM_MAX_DIST,
                                               0,
                                               0)))
        # print('distance', distance_ratio * CAM_MAX_DIST)
        T_world2cam = -1 * R_obj2cam * cam_location

        # Step 3: Fix blender camera's y and z axis direction.
        R_camfix = np.matrix(((1, 0, 0), (0, -1, 0), (0, 0, -1)))
        R_world2cam = R_camfix * R_world2cam
        T_world2cam = R_camfix * T_world2cam

        RT = np.hstack((R_world2cam, T_world2cam))

        return K, RT  
    
  
